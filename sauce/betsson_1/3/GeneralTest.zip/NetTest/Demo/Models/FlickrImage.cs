﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Demo.Models
{
    /// <summary>
    /// Simple model
    /// </summary>
    public class FlickrImage
    {
        public string Title { get; set; }
        public string ImageUrl { get; set; }
    }
}